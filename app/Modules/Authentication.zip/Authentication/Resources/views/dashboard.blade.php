@extends('authentication::layouts.principal.general')
@section('title')
Dashboard
@endsection

@section('content')
zs
@endsection
